const initialState={amount:0}
function Reducers(state=initialState,action){
    if(action.type==='ADD_ONE'){
        return {
            amount: state.amount+1, state

        }
    }
    else if(action.type==='MINUS_ONE'){
        return {
            amount: state.amount-1, state
        }
    }
    else{
        return state;
    }

}
export default Reducers;