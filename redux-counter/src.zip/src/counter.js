import React from 'react';
import './App.css';
import { useDispatch, useSelector } from 'react-redux';

const containerStyle = {
  display: 'flex'
}
const buttonStyle = {
  fontSize: '1.5rem',
  width: '40px',
  height: '40px'
}
export default function Counter() {
    
    const dispatch = useDispatch();
    const dispatch2 = useDispatch()

  
    const amount = useSelector(state=> state.amount)

    console.log(amount)

    return (
      <div className="App" >
        <header className="App-header">
          <h1>{amount}</h1>

          <div style={containerStyle}>
          
             <button type="button" onClick={()=>{dispatch({type:'MINUS_ONE', payload1:0})}} style={buttonStyle}>-</button>
            <button type="button" onClick={()=>{dispatch2({type:'ADD_ONE', payload2:0})}} style={buttonStyle}>+</button>
          </div>
        </header>
      </div>
    );
  }
 